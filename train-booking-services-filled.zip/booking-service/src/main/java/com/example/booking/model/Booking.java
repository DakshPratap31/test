package com.example.booking.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Booking {
    @Id
    private String pnr;
    private Long userId;
    private Long trainId;
    private String travelClass;
    private String status;
    private LocalDateTime bookingTime;

    // Getters and Setters
}