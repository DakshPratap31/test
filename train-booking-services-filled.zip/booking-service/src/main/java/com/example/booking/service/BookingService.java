package com.example.booking.service;

import com.example.booking.model.Booking;
import com.example.booking.repository.BookingRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class BookingService {
    private final BookingRepository bookingRepository;

    public BookingService(BookingRepository bookingRepository) {
        this.bookingRepository = bookingRepository;
    }

    public Booking bookTicket(Long userId, Long trainId, String travelClass) {
        Booking booking = new Booking();
        booking.setPnr(UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        booking.setUserId(userId);
        booking.setTrainId(trainId);
        booking.setTravelClass(travelClass);
        booking.setStatus("BOOKED");
        booking.setBookingTime(LocalDateTime.now());
        return bookingRepository.save(booking);
    }
}