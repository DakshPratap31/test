package com.example.train.model;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
public class Fare {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String travelClass;
    private BigDecimal fare;

    @ManyToOne
    @JoinColumn(name = "train_id")
    private Train train;

    // Getters and Setters
}